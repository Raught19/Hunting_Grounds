
 recipe_military={
{result="hollow-bullet-magazine",energy=3,
ingredients={{"piercing-bullet-magazine", 1},{"copper-plate", 2},{"iron-plate", 2}},
},
{result="incendiary-bullet-magazine",energy=5,
ingredients={{"piercing-bullet-magazine", 1},{"coal", 5}, {"sulfur", 1},{"plastic-bar", 1}},
},
{result="explosive-bullet-magazine",energy=8,
ingredients={{"piercing-bullet-magazine", 1},{"plastic-bar", 1},{"explosives", 2}},
},
{result="machine-gun",energy=8,
ingredients={{"iron-gear-wheel", 20},{"copper-plate", 10},{"steel-plate", 5}, {"battery", 5}},
},
{result="assault-gun",energy=5,
ingredients={{"iron-gear-wheel", 15},{"copper-plate", 10},{"battery", 2}},
},
{result="gatling-gun",energy=10,
ingredients={{"iron-gear-wheel", 40},{"battery", 10},{"steel-plate", 10},{"engine-unit", 1}},
},
}

recipe_military[0]=#recipe_military

local i
for i=1,recipe_military[0] do

data:extend(
{
  {
    type = "recipe",
    name = recipe_military[i].result,
    enabled = false,
    energy_required = recipe_military[i].energy,
    ingredients = recipe_military[i].ingredients,
    result = recipe_military[i].result
  },

}
)
end
