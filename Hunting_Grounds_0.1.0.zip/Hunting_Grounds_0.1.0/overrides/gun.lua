
data.raw.gun["shotgun"].attack_parameters.damage_modifier = 2.00
data.raw.gun["shotgun"].attack_parameters.movement_slow_down_factor=0.35

data.raw.gun["combat-shotgun"].attack_parameters.damage_modifier = 1.4
data.raw.gun["combat-shotgun"].attack_parameters.movement_slow_down_factor=0.55	
	
data.raw.gun["submachine-gun"].attack_parameters.movement_slow_down_factor=0.25
data.raw.gun["submachine-gun"].attack_parameters.range= 18
data.raw.gun["submachine-gun"].attack_parameters.damage_modifier = 1.25

data.raw.gun["pistol"].attack_parameters.movement_slow_down_factor=0.15
data.raw.gun["pistol"].attack_parameters.damage_modifier = 2.00
data.raw.gun["pistol"].attack_parameters.range= 22
data.raw.gun["pistol"].attack_parameters.cooldown = 30

data.raw.gun["rocket-launcher"].attack_parameters.range= 60

data.raw.gun["assault-gun"].subgroup = "Advanced-Weaponry"
data.raw.gun["assault-gun"].attack_parameters.movement_slow_down_factor=0.45  --.attack_parameters.damage_modifier = 1.5
data.raw.gun["assault-gun"].attack_parameters.damage_modifier = 1.15

data.raw.gun["machine-gun"].subgroup = "Advanced-Weaponry"
data.raw.gun["machine-gun"].attack_parameters.movement_slow_down_factor=0.75
--data.raw.gun["machine-gun"].attack_parameters.damage_modifier = 1.10 
data.raw.gun["machine-gun"].attack_parameters.ammo_category="gatling"
data.raw.gun["machine-gun"].attack_parameters.cooldown = 60/30

data.raw.gun["gatling-gun"].subgroup = "Advanced-Weaponry"
data.raw.gun["gatling-gun"].attack_parameters.range= 45
data.raw.gun["gatling-gun"].attack_parameters.movement_slow_down_factor= 0.99 
data.raw.gun["gatling-gun"].attack_parameters.cooldown = 60/60
data.raw.gun["gatling-gun"].attack_parameters.ammo_category="gatling"

data.raw["flame-thrower-explosion"]["flame-thrower-explosion"].damage = {amount = 1, type = "fire"}
data.raw.gun["flame-thrower"].attack_parameters.movement_slow_down_factor = 0.45
data.raw.gun["flame-thrower"].attack_parameters.cooldown = 60/40


data.raw.gun["car-gatling-gun"].attack_parameters.range= 45
data.raw.gun["car-gatling-gun"].attack_parameters.damage_modifier = 1.25
data.raw.gun["car-gatling-gun"].attack_parameters.cooldown = 60/150
data.raw.gun["car-gatling-gun"].attack_parameters.ammo_category="gatling"


data.raw["flame-thrower-explosion"]["flame-thrower-explosion"].damage = {amount = 1, type = "fire"}
data.raw.gun["flame-thrower"].attack_parameters.movement_slow_down_factor = 0.45
data.raw.gun["flame-thrower"].attack_parameters.cooldown = 60/40


data.raw.gun["tank-cannon-flame"].attack_parameters.cooldown = 60/80
data.raw.gun["tank-cannon-flame"].attack_parameters.damage_modifier = 4.0

