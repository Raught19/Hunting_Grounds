
--data.raw["electric-turret"]["laser-turret"].attack_parameters.range = 25
--data.raw["electric-turret"]["laser-turret"].attack_parameters.damage_modifier = 5.00

--data.raw["ammo-turret"]["gun-turret"].attack_parameters.range = 18
--data.raw["ammo-turret"]["gun-turret"].max_health = 600
--data.raw["ammo-turret"]["gun-turret"].inventory_size = 3


data.raw["car"]["tank-flame"].resistances={{type = "fire",decrease=0,percent=100},{type = "physical",decrease=15,percent=30},{type = "impact",decrease=50,percent=60},{type = "explosion",decrease=15,percent=30},{type = "acid",decrease=10,percent=20}}
data.raw["car"]["tank-flame"].max_health=4500

local robores = {{type = "fire",decrease=0,percent=100},{type = "physical",decrease=15,percent=30},{type = "impact",decrease=50,percent=60},{type = "explosion",decrease=15,percent=30},{type = "acid",decrease=10,percent=20}}

data.raw["combat-robot"]["defender"].resistances =  robores
data.raw["combat-robot"]["distractor"].resistances = robores
data.raw["combat-robot"]["destroyer"].resistances = robores



local treehealth = 400
local treeres = {{type = "fire",decrease=0,percent=-200},{type = "poison",decrease=0,percent=-200},{type = "acid",decrease=0,percent=-200}}

data.raw["tree"]["tree-01"].max_health = treehealth
data.raw["tree"]["tree-02"].max_health = treehealth
data.raw["tree"]["tree-02-red"].max_health = treehealth
data.raw["tree"]["tree-03"].max_health = treehealth
data.raw["tree"]["tree-04"].max_health = treehealth
data.raw["tree"]["tree-05"].max_health = treehealth
data.raw["tree"]["tree-06"].max_health = treehealth
data.raw["tree"]["tree-06-brown"].max_health = treehealth
data.raw["tree"]["tree-07"].max_health = treehealth
data.raw["tree"]["tree-08"].max_health = treehealth
data.raw["tree"]["tree-08-brown"].max_health = treehealth
data.raw["tree"]["tree-08-red"].max_health = treehealth
data.raw["tree"]["tree-09"].max_health = treehealth
data.raw["tree"]["tree-09-brown"].max_health = treehealth
data.raw["tree"]["tree-09-red"].max_health = treehealth

data.raw["tree"]["tree-01"].resistances = treeres
data.raw["tree"]["tree-02"].resistances = treeres
data.raw["tree"]["tree-02-red"].resistances = treeres
data.raw["tree"]["tree-03"].resistances = treeres
data.raw["tree"]["tree-04"].resistances = treeres
data.raw["tree"]["tree-05"].resistances = treeres
data.raw["tree"]["tree-06"].resistances = treeres
data.raw["tree"]["tree-06-brown"].resistances = treeres
data.raw["tree"]["tree-07"].resistances = treeres
data.raw["tree"]["tree-08"].resistances = treeres
data.raw["tree"]["tree-08-brown"].resistances = treeres
data.raw["tree"]["tree-08-red"].resistances = treeres
data.raw["tree"]["tree-09"].resistances = treeres
data.raw["tree"]["tree-09-brown"].resistances = treeres
data.raw["tree"]["tree-09-red"].resistances = treeres

data.raw["simple-entity"]["stone-rock"].max_health = 1000
data.raw["simple-entity"]["stone-rock"].resistances = {{type = "fire",decrease=0,percent=100},{type = "poison",decrease=0,percent=100},{type = "physical",decrease=15,percent=30},{type = "impact",decrease=15,percent=30},{type = "explosion",decrease=0,percent=-200},{type = "acid",decrease=5,percent=10}}




--data.raw["ammo-turret"]["gun-turret"].attack_parameters.ammo_category="gatling"


