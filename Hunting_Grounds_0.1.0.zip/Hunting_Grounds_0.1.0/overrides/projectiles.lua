
data.raw.projectile["shotgun-pellet"].action =
    {type = "direct", action_delivery = 
	{ type = "instant", target_effects =
       {type = "damage", damage = {amount = 6, type = "physical"}},
      }
    }
 
  

data.raw.projectile["piercing-shotgun-pellet"].action =
      {type = "direct", action_delivery = 
	{ type = "instant", target_effects =
       {type = "damage", damage = {amount = 6, type = "impact"}},
      }
    }

	--[[
	
		
data.raw.projectile["rocket"].acceleration = 0.025
data.raw.projectile["rocket"].action.action_delivery.target_effects ={
{type = "create-entity", entity_name = "explosion"},
{type = "damage", damage = {amount = 100, type = "fire"} },
{type = "damage", damage = {amount = 280, type = "explosion"} },
{type = "create-entity", entity_name = "small-scorchmark", check_buildability = true}}


data.raw.projectile["explosive-rocket"].acceleration = 0.014
data.raw.projectile["explosive-rocket"].action.action_delivery.target_effects ={
    {type = "create-entity",entity_name = "explosion"},
	{type = "nested-result", action =
	{ type = "area",perimeter = 6, action_delivery = 
	{ type = "instant",target_effects = {
	{type = "damage", damage = {amount = 75, type = "fire"} },
	{type = "damage", damage = {amount = 100, type = "explosion"} },
	{type = "create-entity",entity_name = "explosion"},
	{type = "create-entity", entity_name = "BigFireDoT"}	} } } },}
	
	data.raw["land-mine"]["land-mine"].action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
          {
            type = "nested-result",
            affects_target = true,
            action =
            {
              type = "area",
              perimeter = 6,
              collision_mask = { "player-layer" },
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                  type = "damage",
                  damage = { amount = 500, type = "explosion"}
                }
              }
            },
          },
          {
            type = "create-entity",
            entity_name = "explosion"
          },
		    {
            type = "create-entity",
            entity_name = "BigFireDoT"
          },
          {
            type = "damage",
            damage = { amount = 300, type = "fire"}
          }
        }
      }
    }
	
	]]
	


	
	
	--[[
	
local incendiarybelt = util.table.deepcopy(data.raw.projectile["shotgun-pellet"])
incendiarybelt.name = "fire-belt"
incendiarybelt.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects =
       {type = "damage", damage = {amount = 60, type = "fire"}},
      }}
data:extend({incendiarybelt}) ]]