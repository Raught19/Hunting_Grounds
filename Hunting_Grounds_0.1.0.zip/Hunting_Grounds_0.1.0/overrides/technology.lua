technology_enabled={}
technology_all={}

--technology_all={
if enable_guns then
technology_all[1]={name="cooling",icon="__VanillaEx__/graphics/technology/cooling.png",
effects={
		{type = "unlock-recipe",recipe = "assault-gun"},
		{type = "unlock-recipe",recipe = "machine-gun"},
		{type = "unlock-recipe",recipe = "gatling-gun"},
		{type = "unlock-recipe",recipe = "gatlingbelt-basic"} 
		},
prereq={"military-2", "engine", "sulfur-processing", "battery"},
ingredients={{"science-pack-1", 1},{"science-pack-2", 1}},
count=30,time_r=20,
order="e-c-b-a",
}
table.insert(technology_enabled, technology_all[1])

technology_all[2]={name="ballistics",icon="__VanillaEx__/graphics/technology/ballistics.png",
effects={
		{type = "unlock-recipe",recipe = "hollow-bullet-magazine"},
		{type = "unlock-recipe",recipe = "poison-bullet-magazine"},
		{type = "unlock-recipe",recipe = "incendiary-bullet-magazine"},
		{type = "unlock-recipe",recipe = "explosive-bullet-magazine"}
		},
prereq={"bullet-damage-1","bullet-speed-2", "military-2", "cooling", "plastics"},
ingredients={{"science-pack-1", 1},{"science-pack-2", 1}},
count=50,time_r=30,
order="e-c-b-b",
}
table.insert(technology_enabled, technology_all[2])
end
technology_enabled[0]=#technology_enabled


local i
for i=1,technology_enabled[0] do
data:extend(
{
{
    type = "technology",
    name = technology_enabled[i].name,
    icon = technology_enabled[i].icon,
	icon_size = 128,
    effects = technology_enabled[i].effects,
    prerequisites = technology_enabled[i].prereq,
    unit =
    {
      count = technology_enabled[i].count,
      ingredients = technology_enabled[i].ingredients,
      time = technology_enabled[i].time_r
    },
    order = technology_enabled[i].order,
  },
}
)
end