
data.raw.ammo["piercing-bullet-magazine"].ammo_type.action.action_delivery.target_effects={
    {type = "create-entity",entity_name = "explosion-gunshot-small"},
	{type = "damage", damage = { amount = 2 , type = "physical"}},
	{type = "damage", damage = { amount = 4 , type = "impact"}},}

data.raw.ammo["hollow-bullet-magazine"].subgroup = "Advanced-Bullet"	
data.raw.ammo["hollow-bullet-magazine"].magazine_size = 10
data.raw.ammo["hollow-bullet-magazine"].ammo_type.action[1].action_delivery[1].target_effects={
    {type = "create-entity",entity_name = "explosion-gunshot-small"},
	{type = "damage", damage = { amount = 15 , type = "impact"}},}

data.raw.ammo["incendiary-bullet-magazine"].subgroup = "Advanced-Bullet"	
data.raw.ammo["incendiary-bullet-magazine"].magazine_size = 10
data.raw.ammo["incendiary-bullet-magazine"].ammo_type.action[1].action_delivery[1].target_effects={
	{type = "create-entity",entity_name = "explosion-gunshot"},
	{type = "damage", damage = { amount = 10 , type = "explosion"}},
	{type = "create-entity", entity_name = "FireDoT"}, }

data.raw.ammo["explosive-bullet-magazine"].subgroup = "Advanced-Bullet"	
data.raw.ammo["explosive-bullet-magazine"].magazine_size = 10
data.raw.ammo["explosive-bullet-magazine"].ammo_type.action[1].action_delivery[1].target_effects={
    {type = "create-entity",entity_name = "explosion-hit"},
	{type = "damage", damage = {amount = 5, type = "explosion"}},
	{type = "nested-result", action =
	{type = "area",perimeter = 3, action_delivery = 
	{type = "instant",target_effects = {
	{type = "damage", damage = {amount = 3, type = "fire"} },
	{type = "create-entity",entity_name = "explosion-gunshot-small"} } } } },}

 data.raw.ammo["Biological-bullet-magazine"].subgroup = "Advanced-Bullet"	      

	

