
 recipe_shotgun={
{result="basic-shotgun-slug", energy=3,
ingredients={{"piercing-shotgun-shell", 1},{"copper-plate", 2},{"steel-plate", 5}},
},
{result="explosive-shotgun-slug",energy=6,
ingredients={{"piercing-shotgun-shell", 1},{"explosives", 2},{"steel-plate", 3}}, 
},
{result="buckshot-shotgun-shell", result_count = 5,energy=45, category = "crafting-with-fluid",
ingredients={{"piercing-shotgun-shell", 5}, {"poison-capsule", 1},{"slowdown-capsule", 1},{type="fluid", name="sulfuric-acid", amount=1},},
},
{result="dragon-shotgun-shell",energy=8,
ingredients={{"piercing-shotgun-shell", 1},{"explosives", 4},{"solid-fuel", 4},{"plastic-bar", 1}},
},
{result="biological-shotgun-slug",result_count = 5, energy=5,
ingredients={{"piercing-shotgun-shell", 5},{"alien-artifact", 10},{"plastic-bar", 25}},
},
{result="siege-shotgun", energy=10,
ingredients={{"iron-gear-wheel", 30},{"battery", 10},{"steel-plate", 15}}
},
}

--buckshot biological dragon explosive

recipe_shotgun[0]=#recipe_shotgun
 
local i
for i=1,recipe_shotgun[0] do

data:extend(
{
  {
    type = "recipe",
    name = recipe_shotgun[i].result,
    enabled = false,
    energy_required = recipe_shotgun[i].energy,
    ingredients = recipe_shotgun[i].ingredients,
    result = recipe_shotgun[i].result,
	category = recipe_shotgun[i].category,
	result_count = recipe_shotgun[i].result_count,
  },

}
)
end
