
 recipe_belt={
{result="gatlingbelt-basic",energy=20,
ingredients={{"piercing-bullet-magazine", 10},{"copper-plate", 10},{"steel-plate", 5}},
},
{result="gatlingbelt-hollow",energy=35,
ingredients={{"hollow-bullet-magazine", 10},{"copper-plate", 20},{"steel-plate", 10}}, 
},
{result="gatlingbelt-poison",energy=45, category = "crafting-with-fluid",
ingredients={{"poison-bullet-magazine", 10},{type="fluid", name="sulfuric-acid", amount=5},{"plastic-bar", 10}},
},
{result="gatlingbelt-fire",energy=45,
ingredients={{"incendiary-bullet-magazine", 10},{"sulfur", 5},{"coal", 15},{"plastic-bar", 10}},
},
{result="gatlingbelt-biological",energy=55,
ingredients={{"Biological-bullet-magazine", 10},{"alien-artifact", 10},{"plastic-bar", 25}},
},
}

recipe_belt[0]=#recipe_belt
 
local i
for i=1,recipe_belt[0] do

data:extend(
{
  {
    type = "recipe",
    name = recipe_belt[i].result,
    enabled = false,
    energy_required = recipe_belt[i].energy,
    ingredients = recipe_belt[i].ingredients,
    result = recipe_belt[i].result,
	category = recipe_belt[i].category,
  },

}
)
end
