
 recipe_crate={
{result="gatlingbelt-basic-crate",energy=8,
ingredients={{"gatlingbelt-basic", 50},{"iron-chest", 1}},
},
{result="gatlingbelt-hollow-crate",energy=8,
ingredients={{"gatlingbelt-hollow", 50},{"iron-chest", 1}},
},
{result="gatlingbelt-poison-crate",energy=8,
ingredients={{"gatlingbelt-poison", 50},{"iron-chest", 1}},
},
{result="gatlingbelt-fire-crate",energy=8,
ingredients={{"gatlingbelt-fire", 50},{"iron-chest", 1}},
},
{result="gatlingbelt-biological-crate",energy=8,
ingredients={{"gatlingbelt-biological", 50},{"iron-chest", 1}},
},
{result="poison-bullet-magazine-crate",energy=6,
ingredients={{"poison-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="incendiary-bullet-magazine-crate",energy=6,
ingredients={{"incendiary-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="hollow-bullet-magazine-crate",energy=6,
ingredients={{"hollow-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="explosive-bullet-magazine-crate",energy=6,
ingredients={{"explosive-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="basic-bullet-magazine-crate",energy=6,
ingredients={{"basic-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="piercing-bullet-magazine-crate",energy=6,
ingredients={{"piercing-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="biological-bullet-magazine-crate",energy=6,
ingredients={{"Biological-bullet-magazine", 500},{"wooden-chest", 1}},
},
{result="basic-shotgun-slug-crate", energy=3,
ingredients={{"basic-shotgun-slug", 500},{"wooden-chest", 1}},
},
{result="explosive-shotgun-slug-crate",energy=6,
ingredients={{"explosive-shotgun-slug", 500},{"wooden-chest", 1}},
},
{result="buckshot-shotgun-shell-crate",energy=45,
ingredients={{"buckshot-shotgun-shell", 500},{"wooden-chest", 1}},
},
{result="dragon-shotgun-shell-crate",energy=6,
ingredients={{"dragon-shotgun-shell", 500},{"wooden-chest", 1}},
},
{result="biological-shotgun-slug-crate", energy=6,
ingredients={{"biological-shotgun-slug", 500},{"wooden-chest", 1}},
},
{result="shotgun-shell-crate",energy=6,
ingredients={{"shotgun-shell", 500},{"wooden-chest", 1}},
},
{result="piercing-shotgun-shell-crate",energy=6,
ingredients={{"piercing-shotgun-shell", 500},{"wooden-chest", 1}},
},
}


recipe_crate[0]=#recipe_crate
 
local i
for i=1,recipe_crate[0] do

data:extend(
{
  {
    type = "recipe",
    name = recipe_crate[i].result,
    enabled = false,
    energy_required = recipe_crate[i].energy,
    ingredients = recipe_crate[i].ingredients,
    result = recipe_crate[i].result,
	category = recipe_crate[i].category,
  },

}
)
end
