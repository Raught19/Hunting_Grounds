
 recipe_bullet={
{result="poison-bullet-magazine", result_count = 5,energy=6, category = "crafting-with-fluid",
ingredients={{"piercing-bullet-magazine", 5},{"poison-capsule", 1},{"slowdown-capsule", 1},{type="fluid", name="sulfuric-acid", amount=1}},
},
}

recipe_bullet[0]=#recipe_bullet
 
local i
for i=1,recipe_bullet[0] do

data:extend(
{
  {
    type = "recipe",
    name = recipe_bullet[i].result,
    enabled = false,
    energy_required = recipe_bullet[i].energy,
    ingredients = recipe_bullet[i].ingredients,
    result = recipe_bullet[i].result,
	category = recipe_bullet[i].category,
	result_count = recipe_bullet[i].result_count,
  },

}
)
end
