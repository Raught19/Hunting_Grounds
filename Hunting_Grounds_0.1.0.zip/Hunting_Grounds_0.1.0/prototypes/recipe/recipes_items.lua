
if data.raw.item["alien-artifact-red"] and data.raw.item["alien-artifact-orange"] and data.raw.item["alien-artifact-yellow"] and data.raw.item["alien-artifact-green"] and data.raw.item["alien-artifact-blue"] and data.raw.item["alien-artifact-purple"] then
data:extend({
{
    type = "recipe",
    name = "bio-organic-fuel-from-variety",
    result= "bio-organic-fuel",
	result_count = 3,
    ingredients= { {"alien-artifact-red", 1}, {"alien-artifact-orange", 1}, {"alien-artifact-yellow", 1}, {"alien-artifact-green", 1}, {"alien-artifact-blue", 1}, {"alien-artifact-purple", 1}, {"alien-artifact", 1} },
	energy_required= 5,
    enabled= "true",
	category= "crafting"
  },
 })
 end
 
 data:extend({
  {
    type = "recipe",
    name = "bio-organic-fuel-from-alien-artifact",
    result= "bio-organic-fuel",
    ingredients= { {"alien-artifact", 10} },
	energy_required= 5,
    enabled= "true",
	category= "crafting"
  },
})