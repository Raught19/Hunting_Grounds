data:extend(
{
  {
    type = "technology",
    name = "flamethrower-speed-1",
    icon=modname.."/graphics/technology/flamethrower-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "flame-thrower",
        modifier = "0.2"
      }
    },
    prerequisites = {"flame-thrower"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "e-l-g"
  },
  {
    type = "technology",
    name = "flamethrower-speed-2",
    icon=modname.."/graphics/technology/flamethrower-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "flame-thrower",
        modifier = "0.2"
      }
    },
    prerequisites = {"flamethrower-speed-1"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "e-l-h"
  },
  {
    type = "technology",
    name = "flamethrower-speed-3",
    icon=modname.."/graphics/technology/flamethrower-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "flame-thrower",
        modifier = "0.3"
      }
    },
    prerequisites = {"flamethrower-speed-2"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-l-i"
  },
  {
    type = "technology",
    name = "flamethrower-speed-4",
    icon=modname.."/graphics/technology/flamethrower-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "flame-thrower",
        modifier = "0.3"
      }
    },
    prerequisites = {"flamethrower-speed-3"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-l-j"
  },
  {
    type = "technology",
    name = "flamethrower-speed-5",
    icon=modname.."/graphics/technology/flamethrower-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "flame-thrower",
        modifier = "0.3"
      }
    },
    prerequisites = {"flamethrower-speed-4"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-l-k"
  },
  {
    type = "technology",
    name = "flamethrower-speed-6",
    icon=modname.."/graphics/technology/flamethrower-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "flame-thrower",
        modifier = "0.3"
      }
    },
    prerequisites = {"flamethrower-speed-5"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-l-l"
  }
}
)
