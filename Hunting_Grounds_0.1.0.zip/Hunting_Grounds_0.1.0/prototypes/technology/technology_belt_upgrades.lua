data:extend(
{
  {
    type = "technology",
    name = "gatling-damage-1",
    icon=modname.."/graphics/technology/gatlingammo-damage-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "gatling",
        modifier = "0.05"
      }
    },
    prerequisites = {"belt-fed-ammunition"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 2}
      },
      time = 30
    },
    upgrade = true,
    order = "e-l-a"
  },
  {
    type = "technology",
    name = "gatling-damage-2",
    icon=modname.."/graphics/technology/gatlingammo-damage-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "gatling",
        modifier = "0.05"
      }
    },
    prerequisites = {"gatling-damage-1"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2}
      },
      time = 45
    },
    upgrade = true,
    order = "e-l-b"
  },
  {
    type = "technology",
    name = "gatling-damage-3",
    icon=modname.."/graphics/technology/gatlingammo-damage-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "gatling",
        modifier = "0.1"
      }
    },
    prerequisites = {"gatling-damage-2"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2}
      },
      time = 60
    },
    upgrade = true,
    order = "e-l-c"
  },
  {
    type = "technology",
    name = "gatling-damage-4",
    icon=modname.."/graphics/technology/gatlingammo-damage-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "gatling",
        modifier = "0.1"
      }
    },
    prerequisites = {"gatling-damage-3"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2}
      },
      time = 75
    },
    upgrade = true,
    order = "e-l-d"
  },
  {
    type = "technology",
    name = "gatling-damage-5",
    icon=modname.."/graphics/technology/gatlingammo-damage-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "gatling",
        modifier = "0.4"
      }
    },
    prerequisites = {"gatling-damage-4"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"alien-science-pack", 2},
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2}
      },
      time = 95
    },
    upgrade = true,
    order = "e-l-e"
  },
  {
    type = "technology",
    name = "gatling-damage-6",
    icon=modname.."/graphics/technology/gatlingammo-damage-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "gatling",
        modifier = "0.5"
      }
    },
    prerequisites = {"gatling-damage-5"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"alien-science-pack", 2},
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2}
      },
      time = 105
    },
    upgrade = true,
    order = "e-l-f"
  },
  {
    type = "technology",
    name = "gatling-speed-1",
    icon=modname.."/graphics/technology/gatlingammo-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "gatling",
        modifier = "0.05"
      }
    },
    prerequisites = {"belt-fed-ammunition"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 2}
      },
      time = 30
    },
    upgrade = true,
    order = "e-l-g"
  },
  {
    type = "technology",
    name = "gatling-speed-2",
    icon=modname.."/graphics/technology/gatlingammo-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "gatling",
        modifier = "0.05"
      }
    },
    prerequisites = {"gatling-speed-1"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2}
      },
      time = 45
    },
    upgrade = true,
    order = "e-l-h"
  },
  {
    type = "technology",
    name = "gatling-speed-3",
    icon=modname.."/graphics/technology/gatlingammo-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "gatling",
        modifier = "0.1"
      }
    },
    prerequisites = {"gatling-speed-2"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2}
      },
      time = 60
    },
    upgrade = true,
    order = "e-l-i"
  },
  {
    type = "technology",
    name = "gatling-speed-4",
    icon=modname.."/graphics/technology/gatlingammo-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "gatling",
        modifier = "0.1"
      }
    },
    prerequisites = {"gatling-speed-3"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2}
      },
      time = 75
    },
    upgrade = true,
    order = "e-l-j"
  },
  {
    type = "technology",
    name = "gatling-speed-5",
    icon=modname.."/graphics/technology/gatlingammo-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "gatling",
        modifier = "0.4"
      }
    },
    prerequisites = {"gatling-speed-4"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"alien-science-pack", 2},
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2}
      },
      time = 95
    },
    upgrade = true,
    order = "e-l-k"
  },
  {
    type = "technology",
    name = "gatling-speed-6",
    icon=modname.."/graphics/technology/gatlingammo-speed-upgrade.png",
	icon_size = 128,
    effects =
    {
      {
        type = "gun-speed",
        ammo_category = "gatling",
        modifier = "0.5"
      }
    },
    prerequisites = {"gatling-speed-5"},
    unit =
    {
      count = 300,
      ingredients =
      {
        {"alien-science-pack", 2},
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2}
      },
      time = 105
    },
    upgrade = true,
    order = "e-l-l"
  }
}
)
