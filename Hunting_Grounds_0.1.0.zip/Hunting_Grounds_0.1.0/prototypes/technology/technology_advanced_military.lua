technology_enabled={}
technology_advancedmilitary={}

if enable_guns then
technology_advancedmilitary[1]={name="advanced-military-1",icon="__base__/graphics/technology/military.png",
effects={
		{type = "unlock-recipe",recipe = "basic-shotgun-slug"},
		{type = "unlock-recipe",recipe = "explosive-shotgun-slug"},
		{type = "unlock-recipe",recipe = "buckshot-shotgun-shell"},
		{type = "unlock-recipe",recipe = "dragon-shotgun-shell"}, 
		{type = "unlock-recipe",recipe = "siege-shotgun"} 
		},
prereq={"military-4", "ballistics"},
ingredients={{"science-pack-1", 1},{"science-pack-2", 1},{"science-pack-3", 1},{"alien-science-pack", 1}},
count=300,time_r=45,
order="e-c-b-b",
}

table.insert(technology_enabled, technology_advancedmilitary[1])

technology_advancedmilitary[2]={name="advanced-military-2",icon="__base__/graphics/technology/military.png",
effects={
		{type = "unlock-recipe",recipe = "biological-shotgun-slug"},
		{type = "unlock-recipe",recipe = "gatlingbelt-biological"}
		},
prereq={"advanced-military-1", "AlienUnderstanding-2"},
ingredients={{"science-pack-1", 1},{"science-pack-2", 1},{"science-pack-3", 1},{"alien-science-pack", 1}},
count=300,time_r=60,
order="e-c-b-b",
}

table.insert(technology_enabled, technology_advancedmilitary[2])
end

technology_enabled[0]=#technology_enabled


local i
for i=1,technology_enabled[0] do
data:extend(
{
{
    type = "technology",
    name = technology_enabled[i].name,
    icon = technology_enabled[i].icon,
	icon_size = 128,
    effects = technology_enabled[i].effects,
    prerequisites = technology_enabled[i].prereq,
    unit =
    {
      count = technology_enabled[i].count,
      ingredients = technology_enabled[i].ingredients,
      time = technology_enabled[i].time_r
    },
    order = technology_enabled[i].order,
  },
}
)
end