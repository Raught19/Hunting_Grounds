technology_enabled={}
technology_all={}

--technology_all={
if enable_guns then
technology_all[1]={name="belt-fed-ammunition",icon=modname.."/graphics/technology/gatlingammo.png",
effects={
		{type = "unlock-recipe",recipe = "gatlingbelt-hollow"},
		{type = "unlock-recipe",recipe = "gatlingbelt-poison"},
		{type = "unlock-recipe",recipe = "gatlingbelt-fire"}
		},
prereq={"military-3", "ballistics"},
ingredients={{"science-pack-1", 1},{"science-pack-2", 1},{"science-pack-3", 1}},
count=300,time_r=30,
order="e-c-b-b",
}

table.insert(technology_enabled, technology_all[1])
end

technology_enabled[0]=#technology_enabled


local i
for i=1,technology_enabled[0] do
data:extend(
{
{
    type = "technology",
    name = technology_enabled[i].name,
    icon = technology_enabled[i].icon,
	icon_size = 128,
    effects = technology_enabled[i].effects,
    prerequisites = technology_enabled[i].prereq,
    unit =
    {
      count = technology_enabled[i].count,
      ingredients = technology_enabled[i].ingredients,
      time = technology_enabled[i].time_r
    },
    order = technology_enabled[i].order,
  },
}
)
end