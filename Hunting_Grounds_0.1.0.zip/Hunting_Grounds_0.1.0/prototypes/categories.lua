
data:extend(
{
    {
    type = "ammo-category",
	target_type = "direction",
    name = "gatling"
  },
}
)