

local item_ammo_new={}

item_ammo_new[1]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_new[1].name="gatlingbelt-fire"
item_ammo_new[1].ammo_type.target_type = "direction"
item_ammo_new[1].ammo_type.category ="gatling"
item_ammo_new[1].magazine_size= 100
item_ammo_new[1].stack_size = 10
item_ammo_new[1].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "fire-belt",
            starting_speed = 2,
            direction_deviation = 0.6,
            range_deviation = .6,
            max_range = 45
          }
        }
}
--item_ammo_new[1].order="a[flame-thrower-ammo] -e"
item_ammo_new[1].subgroup = "Belt-Ammunition"

item_ammo_new[2]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_new[2].name="gatlingbelt-basic"
item_ammo_new[2].ammo_type.target_type = "direction"
item_ammo_new[2].ammo_type.category ="gatling"
item_ammo_new[2].magazine_size= 100
item_ammo_new[2].stack_size = 10
item_ammo_new[2].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "basic-belt",
            starting_speed = 1,
            direction_deviation = .2,
            range_deviation = .7,
            max_range = 45
          }
        }
}
--item_ammo_new[2].order="a[flame-thrower-ammo]-a"
item_ammo_new[2].subgroup = "Belt-Ammunition"

item_ammo_new[3]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_new[3].name="gatlingbelt-hollow"
item_ammo_new[3].ammo_type.target_type = "direction"
item_ammo_new[3].ammo_type.category ="gatling"
item_ammo_new[3].magazine_size= 100
item_ammo_new[3].stack_size = 10
item_ammo_new[3].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "hollow-belt",
            starting_speed = 1,
            direction_deviation = .1,
            range_deviation = .8,
            max_range = 45
          }
        }
}
--item_ammo_new[3].order="a[flame-thrower-ammo]-b"
item_ammo_new[3].subgroup = "Belt-Ammunition"

item_ammo_new[4]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_new[4].name="gatlingbelt-poison"
item_ammo_new[4].ammo_type.target_type = "direction"
item_ammo_new[4].ammo_type.category ="gatling"
item_ammo_new[4].magazine_size= 100
item_ammo_new[4].stack_size = 10
item_ammo_new[4].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "poison-belt",
            starting_speed = 1,
            direction_deviation = .4,
            range_deviation = .8,
            max_range = 45
          }
        }
}
--item_ammo_new[4].order="a[flame-thrower-ammo]-c"
item_ammo_new[4].subgroup = "Belt-Ammunition"

item_ammo_new[5]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_new[5].name="poison-bullet-magazine"
item_ammo_new[5].ammo_type.action[1].action_delivery[1].target_effects ={
		{type = "damage", damage = {amount = 3, type = "poison"}},
		{type = "damage", damage = {amount = 3, type = "acid"}},
		 {type = "create-sticker",
          sticker = "little-sticker"}
                }
--item_ammo_new[5].order="a[basic-clips]-b[piercing-bullet-magazine]-a"
item_ammo_new[5].subgroup = "Advanced-Bullet"

item_ammo_new[6]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_new[6].name="explosive-shotgun-slug"
item_ammo_new[6].ammo_type.target_type = "direction"
item_ammo_new[6].ammo_type.category ="shotgun-shell"
item_ammo_new[6].magazine_size= 10
item_ammo_new[6].stack_size = 100
item_ammo_new[6].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "explosive-slug",
            starting_speed = .8,
            direction_deviation = .04,
            range_deviation = .5,
            max_range = 25
          }
        }
}
--item_ammo_new[6].order="a[flame-thrower-ammo]-c"
item_ammo_new[6].subgroup = "Advanced-Shotgun"

item_ammo_new[7]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_new[7].name="biological-shotgun-slug"
item_ammo_new[7].ammo_type.target_type = "direction"
item_ammo_new[7].ammo_type.category ="shotgun-shell"
item_ammo_new[7].magazine_size= 10
item_ammo_new[7].stack_size = 100
item_ammo_new[7].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "biological-slug",
            starting_speed = .8,
            direction_deviation = .04,
            range_deviation = .5,
            max_range = 25
          }
        }
}
--item_ammo_new[7].order="a[flame-thrower-ammo]-c"
item_ammo_new[7].subgroup = "Advanced-Shotgun"


item_ammo_new[8]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_new[8].name="buckshot-shotgun-shell"
item_ammo_new[8].ammo_type.target_type = "direction"
item_ammo_new[8].ammo_type.category ="shotgun-shell"
item_ammo_new[8].magazine_size= 10
item_ammo_new[8].stack_size = 100
item_ammo_new[8].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 28,
          action_delivery =
          {
		  {type = "projectile",
            projectile = "buckshot-shell",
            starting_speed = 1,
			speed_deviation = 0.01,
            direction_deviation = .9,
            range_deviation = .9,
			starting_distance = 0.6,
            max_range = 15}}
			
          }
        }
--item_ammo_new[8].order="a[flame-thrower-ammo]-c"
item_ammo_new[8].subgroup = "Advanced-Shotgun"

item_ammo_new[9]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_new[9].name="dragon-shotgun-shell"
item_ammo_new[9].ammo_type.target_type = "direction"
item_ammo_new[9].ammo_type.category ="shotgun-shell"
item_ammo_new[9].magazine_size= 10
item_ammo_new[9].stack_size = 100
item_ammo_new[9].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 12,
          action_delivery =
          {
		  {type = "projectile",
            projectile = "dragons-breath",
            starting_speed = 1,
			speed_deviation = 0.5,
            direction_deviation = .05,
            range_deviation = .01,
			starting_distance = 0.6,
            max_range = 20}}
			
          }
        }
--item_ammo_new[9].order="a[flame-thrower-ammo]-c"
item_ammo_new[9].subgroup = "Advanced-Shotgun"


item_ammo_new[10]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_new[10].name="gatlingbelt-biological"
item_ammo_new[10].ammo_type.target_type = "direction"
item_ammo_new[10].ammo_type.category ="gatling"
item_ammo_new[10].magazine_size= 100
item_ammo_new[10].stack_size = 10
item_ammo_new[10].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "biological-belt",
            starting_speed = 1,
            direction_deviation = .2,
            range_deviation = .7,
            max_range = 45
          }
        }
}
--item_ammo_new[10].order="a[flame-thrower-ammo]-a"
item_ammo_new[10].subgroup = "Belt-Ammunition"

item_ammo_new[11]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_new[11].name="basic-shotgun-slug"
item_ammo_new[11].ammo_type.target_type = "direction"
item_ammo_new[11].ammo_type.category ="shotgun-shell"
item_ammo_new[11].magazine_size= 10
item_ammo_new[11].stack_size = 100
item_ammo_new[11].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "basic-slug",
            starting_speed = .8,
            direction_deviation = .04,
            range_deviation = .5,
            max_range = 25
          }
        }
}
--item_ammo_new[11].order="a[flame-thrower-ammo]-c"
item_ammo_new[11].subgroup = "Advanced-Shotgun"

item_ammo_new[0]=#item_ammo_new


for i=1,item_ammo_new[0] do -- Generates icons and minable.result using name
item_ammo_new[i].icon=toicon(item_ammo_new[i].name)
end

for e=1,item_ammo_new[0] do -- Extends Factorio table (adds entity to the game)
data:extend({
item_ammo_new[e],
})
end
