

   data:extend({
{
    type = "item",
    name = "bio-organic-fuel",
    icon = modname.."/graphics/icons/bio-fuel.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "125MJ",
    subgroup = "raw-resource",
    order = "c[solid-fuel]",
    stack_size = 10
  }
  
  })