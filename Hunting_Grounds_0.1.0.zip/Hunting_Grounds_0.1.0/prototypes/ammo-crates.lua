

local item_ammo_crate={}

item_ammo_crate[1]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[1].name="gatlingbelt-fire-crate"
item_ammo_crate[1].ammo_type.target_type = "direction"
item_ammo_crate[1].ammo_type.category ="gatling"
item_ammo_crate[1].magazine_size= 5000
item_ammo_crate[1].stack_size = 2
item_ammo_crate[1].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "fire-belt-crate",
            starting_speed = 2,
            direction_deviation = 0.6,
            range_deviation = .6,
            max_range = 45
          }
        }
}
item_ammo_crate[1].subgroup = "Ammunition-Crates"
--item_ammo_crate[1].order="a[flame-thrower-ammo] -e"


--[[ subgroup = "Materials",
		order = "b[Building_Materials]",]]

item_ammo_crate[2]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[2].name="gatlingbelt-basic-crate"
item_ammo_crate[2].ammo_type.target_type = "direction"
item_ammo_crate[2].ammo_type.category ="gatling"
item_ammo_crate[2].magazine_size= 5000
item_ammo_crate[2].stack_size = 2
item_ammo_crate[2].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "basic-belt-crate",
            starting_speed = 1,
            direction_deviation = .2,
            range_deviation = .7,
            max_range = 45
          }
        }
}
item_ammo_crate[2].subgroup = "Ammunition-Crates"
--item_ammo_crate[2].order="a[flame-thrower-ammo]-a"

item_ammo_crate[3]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[3].name="gatlingbelt-hollow-crate"
item_ammo_crate[3].ammo_type.target_type = "direction"
item_ammo_crate[3].ammo_type.category ="gatling"
item_ammo_crate[3].magazine_size= 5000
item_ammo_crate[3].stack_size = 2
item_ammo_crate[3].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "hollow-belt-crate",
            starting_speed = 1,
            direction_deviation = .1,
            range_deviation = .8,
            max_range = 45
          }
        }
}
item_ammo_crate[3].subgroup = "Ammunition-Crates"
--item_ammo_crate[3].order="a[flame-thrower-ammo]-b"

item_ammo_crate[4]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[4].name="gatlingbelt-poison-crate"
item_ammo_crate[4].ammo_type.target_type = "direction"
item_ammo_crate[4].ammo_type.category ="gatling"
item_ammo_crate[4].magazine_size= 5000
item_ammo_crate[4].stack_size = 2
item_ammo_crate[4].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "poison-belt-crate",
            starting_speed = 1,
            direction_deviation = .4,
            range_deviation = .8,
            max_range = 45
          }
        }
}
item_ammo_crate[4].subgroup = "Ammunition-Crates"
--item_ammo_crate[4].order="a[flame-thrower-ammo]-c"

item_ammo_crate[5]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[5].name="poison-bullet-magazine-crate"
item_ammo_crate[5].magazine_size= 5000
item_ammo_crate[5].stack_size = 2
item_ammo_crate[5].ammo_type.action[1].action_delivery[1].target_effects ={
		{type = "damage", damage = {amount = 2.4, type = "poison"}},
		{type = "damage", damage = {amount = 2.4, type = "acid"}},
		 {type = "create-sticker",
          sticker = "little-sticker"}
                }
item_ammo_crate[5].subgroup = "Ammunition-Crates"				
--item_ammo_crate[5].order="a[basic-clips]-b[piercing-bullet-magazine]-a"

item_ammo_crate[6]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_crate[6].name="explosive-shotgun-slug-crate"
item_ammo_crate[6].ammo_type.target_type = "direction"
item_ammo_crate[6].ammo_type.category ="shotgun-shell"
item_ammo_crate[6].magazine_size= 5000
item_ammo_crate[6].stack_size = 2
item_ammo_crate[6].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "explosive-slug-crate",
            starting_speed = .8,
            direction_deviation = .04,
            range_deviation = .5,
            max_range = 25
          }
        }
}
item_ammo_crate[6].subgroup = "Ammunition-Crates"
item_ammo_crate[6].order="a[piercing-shotgun-shell-crate]-c"

item_ammo_crate[7]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_crate[7].name="biological-shotgun-slug-crate"
item_ammo_crate[7].ammo_type.target_type = "direction"
item_ammo_crate[7].ammo_type.category ="shotgun-shell"
item_ammo_crate[7].magazine_size= 5000
item_ammo_crate[7].stack_size = 2
item_ammo_crate[7].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "biological-slug-crate",
            starting_speed = .8,
            direction_deviation = .04,
            range_deviation = .5,
            max_range = 25
          }
        }
}
item_ammo_crate[7].subgroup = "Ammunition-Crates"
item_ammo_crate[7].order="a[piercing-shotgun-shell-crate]-c"


item_ammo_crate[8]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_crate[8].name="buckshot-shotgun-shell-crate"
item_ammo_crate[8].ammo_type.target_type = "direction"
item_ammo_crate[8].ammo_type.category ="shotgun-shell"
item_ammo_crate[8].magazine_size= 5000
item_ammo_crate[8].stack_size = 2
item_ammo_crate[8].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 28,
          action_delivery =
          {
		  {type = "projectile",
            projectile = "buckshot-shell-crate",
            starting_speed = 1,
			speed_deviation = 0.01,
            direction_deviation = .9,
            range_deviation = .9,
			starting_distance = 0.6,
            max_range = 15}}
			
          }
        }
item_ammo_crate[8].subgroup = "Ammunition-Crates"		
item_ammo_crate[8].order="a[piercing-shotgun-shell-crate]-c"

item_ammo_crate[9]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_crate[9].name="dragon-shotgun-shell-crate"
item_ammo_crate[9].ammo_type.target_type = "direction"
item_ammo_crate[9].ammo_type.category ="shotgun-shell"
item_ammo_crate[9].magazine_size= 5000
item_ammo_crate[9].stack_size = 2
item_ammo_crate[9].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 12,
          action_delivery =
          {
		  {type = "projectile",
            projectile = "dragons-breath-crate",
            starting_speed = 1,
			speed_deviation = 0.5,
            direction_deviation = .05,
            range_deviation = .01,
			starting_distance = 0.6,
            max_range = 20}}
			
          }
        }
item_ammo_crate[9].subgroup = "Ammunition-Crates"		
item_ammo_crate[9].order="a[piercing-shotgun-shell-crate]-c"


item_ammo_crate[10]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[10].name="gatlingbelt-biological-crate"
item_ammo_crate[10].ammo_type.target_type = "direction"
item_ammo_crate[10].ammo_type.category ="gatling"
item_ammo_crate[10].magazine_size= 5000
item_ammo_crate[10].stack_size = 2
item_ammo_crate[10].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "biological-belt-crate",
            starting_speed = 1,
            direction_deviation = .2,
            range_deviation = .7,
            max_range = 45
          }
        }
}
item_ammo_crate[10].subgroup = "Ammunition-Crates"
--item_ammo_crate[10].order="a[flame-thrower-ammo]-a"

item_ammo_crate[11]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_crate[11].name="basic-shotgun-slug-crate"
item_ammo_crate[11].ammo_type.target_type = "direction"
item_ammo_crate[11].ammo_type.category ="shotgun-shell"
item_ammo_crate[11].magazine_size= 5000
item_ammo_crate[11].stack_size = 2
item_ammo_crate[11].ammo_type.action = {
 {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "basic-slug-crate",
            starting_speed = .8,
            direction_deviation = .04,
            range_deviation = .5,
            max_range = 25
          }
        }
}
item_ammo_crate[11].subgroup = "Ammunition-Crates"
item_ammo_crate[11].order="a[piercing-shotgun-shell-crate]-c"

item_ammo_crate[12]=util.table.deepcopy(data.raw["ammo"]["hollow-bullet-magazine"])
item_ammo_crate[12].name="hollow-bullet-magazine-crate"
item_ammo_crate[12].magazine_size= 5000
item_ammo_crate[12].stack_size = 2
item_ammo_crate[12].ammo_type.action[1].action_delivery[1].target_effects={
    {type = "create-entity",entity_name = "explosion-gunshot-small"},
	{type = "damage", damage = { amount = 18 , type = "impact"}},}
item_ammo_crate[12].subgroup = "Ammunition-Crates"
--item_ammo_crate[12].order="a[basic-clips]-a[basic-bullet-magazine]-a"

item_ammo_crate[13]=util.table.deepcopy(data.raw["ammo"]["incendiary-bullet-magazine"])
item_ammo_crate[13].name="incendiary-bullet-magazine-crate"
item_ammo_crate[13].magazine_size= 5000
item_ammo_crate[13].stack_size = 2
item_ammo_crate[13].ammo_type.action[1].action_delivery[1].target_effects={
	{type = "create-entity",entity_name = "explosion-gunshot"},
	{type = "damage", damage = { amount = 12 , type = "explosion"}},
	{type = "create-entity", entity_name = "FireDoT"}, }
item_ammo_crate[13].subgroup = "Ammunition-Crates"	
--item_ammo_crate[13].order="a[basic-clips]-b[piercing-bullet-magazine]-a"

item_ammo_crate[14]=util.table.deepcopy(data.raw["ammo"]["explosive-bullet-magazine"])
item_ammo_crate[14].name="explosive-bullet-magazine-crate"
item_ammo_crate[14].magazine_size= 5000
item_ammo_crate[14].stack_size = 2
item_ammo_crate[14].ammo_type.action[1].action_delivery[1].target_effects={
    {type = "create-entity",entity_name = "explosion-hit"},
	{type = "damage", damage = {amount = 6, type = "explosion"}},
	{type = "nested-result", action =
	{type = "area",perimeter = 3.6, action_delivery = 
	{type = "instant",target_effects = {
	{type = "damage", damage = {amount = 3, type = "fire"} },
	{type = "create-entity",entity_name = "explosion-gunshot-small"} } } } },}
--item_ammo_crate[14].order="a[basic-clips]-b[piercing-bullet-magazine]-b"
item_ammo_crate[14].subgroup = "Ammunition-Crates"

item_ammo_crate[15]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[15].name="basic-bullet-magazine-crate"
item_ammo_crate[15].magazine_size= 5000
item_ammo_crate[15].stack_size = 2
item_ammo_crate[15].ammo_type.action[1].action_delivery[1].target_effects={
				{type = "create-entity",
                  entity_name = "explosion-hit" },
                {type = "damage",damage = { amount = 2.4 , type = "physical"}}}
item_ammo_crate[15].order="a[basic-bullet-magazine-crate]"
item_ammo_crate[15].subgroup = "Ammunition-Crates"

item_ammo_crate[16]=util.table.deepcopy(data.raw["ammo"]["piercing-bullet-magazine"])
item_ammo_crate[16].name="piercing-bullet-magazine-crate"
item_ammo_crate[16].magazine_size= 5000
item_ammo_crate[16].stack_size = 2
item_ammo_crate[16].ammo_type.action.action_delivery.target_effects={
    {type = "create-entity",entity_name = "explosion-gunshot-small"},
	{type = "damage", damage = { amount = 2.4 , type = "physical"}},
	{type = "damage", damage = { amount = 4.8 , type = "impact"}},}
item_ammo_crate[16].order="a[basic-bullet-magazine-crate]-b[piercing-bullet-magazine-crate]-b"
item_ammo_crate[16].subgroup = "Ammunition-Crates"

item_ammo_crate[17]=util.table.deepcopy(data.raw["ammo"]["shotgun-shell"])
item_ammo_crate[17].name="shotgun-shell-crate"
item_ammo_crate[17].ammo_type.target_type = "direction"
item_ammo_crate[17].ammo_type.category ="shotgun-shell"
item_ammo_crate[17].magazine_size= 5000
item_ammo_crate[17].stack_size = 2
item_ammo_crate[17].ammo_type.action = {
 {
          type = "direct",
		  repeat_count = 12,
          action_delivery =
          {
            type = "projectile",
            projectile = "shotgun-pellet-crate",
			starting_speed = 1,
            direction_deviation = 0.3,
            range_deviation = 0.3,
            max_range = 15
          }
        }
}
item_ammo_crate[17].order="a[basic-bullet-magazine-crate]-b[piercing-bullet-magazine-crate]-b"
item_ammo_crate[17].subgroup = "Ammunition-Crates"

item_ammo_crate[18]=util.table.deepcopy(data.raw["ammo"]["piercing-shotgun-shell"])
item_ammo_crate[18].name="piercing-shotgun-shell-crate"
item_ammo_crate[18].ammo_type.target_type = "direction"
item_ammo_crate[18].ammo_type.category ="shotgun-shell"
item_ammo_crate[18].magazine_size= 5000
item_ammo_crate[18].stack_size = 2
item_ammo_crate[18].ammo_type.action = {
 {
          type = "direct",
           repeat_count = 16,
        action_delivery =
        {
          type = "projectile",
          projectile = "piercing-shotgun-pellet",
          starting_speed = 1,
          direction_deviation = 0.3,
          range_deviation = 0.3,
          max_range = 15,
        }
		}
}
item_ammo_crate[18].order="a[shotgun-shell-crate]-b[piercing-shotgun-shell]-b"
item_ammo_crate[18].subgroup = "Ammunition-Crates"

item_ammo_crate[19]=util.table.deepcopy(data.raw["ammo"]["basic-bullet-magazine"])
item_ammo_crate[19].name="biological-bullet-magazine-crate"
item_ammo_crate[19].magazine_size= 5000
item_ammo_crate[19].stack_size = 2
item_ammo_crate[19].ammo_type.action[1].action_delivery[1].target_effects ={
{type = "create-entity", entity_name = "explosion-gunshot-small"},
				{type = "damage", damage = { amount = ((NEConfig.BioDamage/NEConfig.Set_Difficulty) + 5) * 1.2, type = "Biological"},
				{type = "damage", damage = { amount = 6 , type = "physical"}
				}}}
--item_ammo_crate[19].order="a[basic-clips]-b[piercing-bullet-magazine]-a"
item_ammo_crate[19].subgroup = "Ammunition-Crates"

item_ammo_crate[0]=#item_ammo_crate

for i=1,item_ammo_crate[0] do -- Generates icons and minable.result using name
item_ammo_crate[i].icon=toicon(item_ammo_crate[i].name)
end

for e=1,item_ammo_crate[0] do -- Extends Factorio table (adds entity to the game)
data:extend({
item_ammo_crate[e],
})
end
