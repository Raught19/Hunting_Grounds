local item_gun={}


item_gun[1]=util.table.deepcopy(data.raw["gun"]["shotgun"])
item_gun[1].name="siege-shotgun"
item_gun[1].icon=toicon(item_gun[1].name)
item_gun[1].subgroup = "Advanced-Weaponry"
item_gun[1].attack_parameters.cooldown=60/3
item_gun[1].attack_parameters.damage_modifier = 1.00
item_gun[1].attack_parameters.range=20
item_gun[1].attack_parameters.movement_slow_down_factor=0.75

item_gun[0]=#item_gun -- Finds size of table (# of projectiles)

for e=1,item_gun[0] do -- Extends Factorio table (adds entity to the game)
data:extend({
item_gun[e],
})
end
			