data:extend(
{

  {
    type = "item-group",
    name = "Advanced-Combat",
	icon = modname.."/graphics/icons/advanced-combat.png",
    inventory_order = "y",
    order = "z",
  },

  {
    type = "item-subgroup",
    name = "Advanced-Weaponry",
    group = "Advanced-Combat",
    order = "e",
  },

  {
    type = "item-subgroup",
    name = "Advanced-Bullet",
    group = "Advanced-Combat",
    order = "f",
  },
  
    {
    type = "item-subgroup",
    name = "Advanced-Shotgun",
    group = "Advanced-Combat",
    order = "g",
  },
  
    {
    type = "item-subgroup",
    name = "Belt-Ammunition",
    group = "Advanced-Combat",
    order = "h",
  },
  
  {
    type = "item-subgroup",
    name = "Advanced-Vehicles",
    group = "Advanced-Combat",
    order = "i",
  },
  
    {
    type = "item-subgroup",
    name = "Advanced-Artillery",
    group = "Advanced-Combat",
    order = "j",
  },

  {
    type = "item-subgroup",
    name = "Ammunition-Crates",
    group = "Advanced-Combat",
    order = "k",
  },
  
})