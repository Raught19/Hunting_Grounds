data:extend({
{
    type = "flame-thrower-explosion",
    name = "flame-thrower-explosion-new",
    flags = {"not-on-map"},
    animation_speed = 1,
    animations =
    {
      {
        filename = "__base__/graphics/entity/flame-thrower-explosion/flame-thrower-explosion.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        frame_count = 64,
        line_length = 8
      }
    },
    light = {intensity = 0.2, size = 20},
    slow_down_factor = 1,
    smoke = "smoke-fast",
    smoke_count = 1,
    smoke_slow_down_factor = 0.95,
    damage = {amount = 1, type = "fire"},
	 
	 action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
	{type = "create-entity", entity_name = "FireDoT"}}}}
  
  }})
  
  data:extend({
{
    type = "smoke-with-trigger",
    name = "FireDoT",
    flags = {"not-on-map"},
	animation_speed = .1,
    show_when_smoke_off = true,
    animation =
    {
      filename = modname.."/graphics/entity/fire/fire_ground2.png",
      priority = "extra-high",
		width = 200,
        height = 200,
        frame_count = 16,
        line_length = 4,
      scale = .5
    },
	light = {intensity = 0.2, size = 20},
    slow_down_factor = 0,
    affected_by_wind = false,
    cyclic = true,
    duration = 60 * 2,
    fade_away_duration = 0,
    spread_duration = 10,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
		
          {type = "nested-result",
          action =
          {
            type = "area",
            perimeter = 1.5,
            entity_flags = {"breaths-air"},
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                type = "damage",
                damage = { amount = 5, type = "fire"}
              }}
            }
          },
		  {type = "create-entity",entity_name = "explosion-gunshot-small"}, 
        }
      }
    },
    action_frequency = 15
  }
  })
  
   data:extend({
{
    type = "smoke-with-trigger",
    name = "BigFireDoT",
    flags = {"not-on-map"},
	animation_speed = .1,
    show_when_smoke_off = true,
    animation =
    {
      filename = modname.."/graphics/entity/fire/fire_ground2.png",
      priority = "extra-high",
		width = 200,
        height = 200,
        frame_count = 16,
        line_length = 4,
      scale = .8
    },
	light = {intensity = 0.2, size = 20},
    slow_down_factor = 0,
	smoke = {
        {
          name = "train-smoke",
          deviation = {0.3, 0.3},
          frequency = 100,
          position = {0, 0},
          starting_frame = 0,
          starting_frame_deviation = 60,
          height = 64,
          height_deviation = 0.5,
          starting_vertical_speed = 4,
          starting_vertical_speed_deviation = 0.6,
		  offset_deviation = {{0.3, -2.7}, {0.75, 2.7}}
        }
      },
    smoke_count = 1,
    smoke_slow_down_factor = 0.95,
    affected_by_wind = false,
    cyclic = true,
    duration = 60 * 3.5,
    fade_away_duration = 0,
    spread_duration = 10,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
		
          {type = "nested-result",
          action =
          {
            type = "area",
            perimeter = 2,
            entity_flags = {"breaths-air"},
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                type = "damage",
                damage = { amount = 5, type = "fire"}
              }}
            }
          },
		  {type = "create-entity",entity_name = "explosion-gunshot-small"}, 
        }
      }
    },
    action_frequency = 15
  }
  })
  
  data:extend({
  {
    type = "sticker",
    name = "tiny-sticker",
    flags = {"not-on-map"},
    --icon = "__base__/graphics/icons/slowdown-sticker.png",
    flags = {},
    animation =
    {
      filename = "__base__/graphics/entity/slowdown-sticker/slowdown-sticker.png",
      priority = "extra-high",
      width = 11,
      height = 11,
      frame_count = 13,
      animation_speed = 0.4
    },
    duration_in_ticks = 60 * .5,
    magnitude = 0.2
  }, 
  })
  
   data:extend({
  {
    type = "sticker",
    name = "little-sticker",
    flags = {"not-on-map"},
    --icon = "__base__/graphics/icons/slowdown-sticker.png",
    flags = {},
    animation =
    {
      filename = "__base__/graphics/entity/slowdown-sticker/slowdown-sticker.png",
      priority = "extra-high",
      width = 11,
      height = 11,
      frame_count = 13,
      animation_speed = 0.4
    },
    duration_in_ticks = 60 * 2,
    magnitude = 0.5
  }, 
  })
  
  
     data:extend({
  {
    type = "sticker",
    name = "medium-sticker",
    flags = {"not-on-map"},
    --icon = "__base__/graphics/icons/slowdown-sticker.png",
    flags = {},
    animation =
    {
      filename = "__base__/graphics/entity/slowdown-sticker/slowdown-sticker.png",
      priority = "extra-high",
      width = 11,
      height = 11,
      frame_count = 13,
      animation_speed = 0.4
    },
    duration_in_ticks = 60 * 3,
    magnitude = 0.5
  }, 
  })