
local basicbelt = util.table.deepcopy(data.raw.projectile["shotgun-pellet"])
basicbelt.name = "basic-belt-crate"
basicbelt.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 18, type = "physical"}},
		{type = "damage", damage = {amount = 18, type = "impact"}},
                }}}
data:extend({basicbelt})


local hollowbelt = util.table.deepcopy(data.raw.projectile["shotgun-pellet"]) --filename = "__base__/graphics/entity/piercing-bullet/piercing-bullet.png",
hollowbelt.name = "hollow-belt-crate"
hollowbelt.animation ={
      filename = "__base__/graphics/entity/piercing-bullet/piercing-bullet.png",
      frame_count = 1,
      width = 3,
      height = 50,
      priority = "high"
    }
hollowbelt.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 18, type = "physical"}},
		{type = "damage", damage = {amount = 36, type = "impact"}},
                }}}
data:extend({hollowbelt})

local poisonbelt = util.table.deepcopy(data.raw.projectile["shotgun-pellet"])
poisonbelt.name = "poison-belt-crate"
poisonbelt.animation ={
      filename = modname.."/graphics/entity/projectiles/poison-bullet.png",
      frame_count = 1,
      width = 3,
      height = 50,
      priority = "high"
    }
poisonbelt.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 18, type = "poison"}},
		{type = "damage", damage = {amount = 24, type = "acid"}},
		{type = "create-sticker",
          sticker = "medium-sticker"},
                }}}
data:extend({poisonbelt})


local incendiarybelt = util.table.deepcopy(data.raw.projectile["shotgun-pellet"])
incendiarybelt.name = "fire-belt-crate"
incendiarybelt.animation ={
      filename = modname.."/graphics/entity/projectiles/fire-bullet.png",
      frame_count = 1,
      width = 3,
      height = 50,
      priority = "high"
    }
incendiarybelt.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 60, type = "explosion"}},
		{type = "create-entity", entity_name = "FireDoT"} },
                }}
data:extend({incendiarybelt})


local explosiveslug = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
explosiveslug.name = "explosive-slug-crate"
explosiveslug.animation ={
     filename = modname.."/graphics/entity/projectiles/shotgun-explosive-slug.png",
        priority = "extra-high",
        width = 3,
        height = 28,
        frame_count = 1,
        line_length = 1,
		scale = 3
		}
explosiveslug.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
    {type = "create-entity",entity_name = "explosion"},
	{type = "damage", damage = {amount = 76.8, type = "explosion"}},
	{type = "nested-result", action =
	{type = "area",perimeter = 4, action_delivery = 
	{type = "instant",target_effects = {
	{type = "damage", damage = {amount = 24, type = "explosion"} },
	{type = "create-entity",entity_name = "explosion-hit"} } } } }}}}
data:extend({explosiveslug})

local dragonsbreath = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
dragonsbreath.animation ={
     filename = modname.."/graphics/entity/dragon-explosion/dragons-breath.png",
        priority = "extra-high",
        width = 64,
        height = 64,
        frame_count = 16,
        line_length = 4,
		scale = 1.2
		}
dragonsbreath.name = "dragons-breath-crate"
dragonsbreath.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 12, type = "explosion"}},
		{type = "create-entity", entity_name = "FireDoT"} },
                }}
data:extend({dragonsbreath})



local bioslug = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
bioslug.name = "biological-slug-crate"
bioslug.animation ={
     filename = modname.."/graphics/entity/projectiles/shotgun-biological-slug.png",
        priority = "extra-high",
        width = 3,
        height = 28,
        frame_count = 1,
        line_length = 1,
		scale = 3
		}
bioslug.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = (((NEConfig.BioDamage/NEConfig.Set_Difficulty) + 5) * 10) * 1.2, type = "Biological"}}
                }}}
data:extend({bioslug})

local basicslug = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
basicslug.name = "basic-slug-crate"
basicslug.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 128, type = "impact"}}
                }}}
data:extend({basicslug})


local buckshot = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
buckshot.name = "buckshot-shell-crate"
buckshot.animation ={
     filename = modname.."/graphics/entity/projectiles/shotgun-buckshot5x6.png",
        priority = "extra-high",
        width = 5,
        height = 6,
        frame_count = 10,
        line_length = 5,
		scale = 3
		}
buckshot.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = 2.4, type = "poison"}},
		{type = "damage", damage = {amount = 2.4, type = "acid"}},
		{type = "create-sticker",
          sticker = "little-sticker"},
                }}}
data:extend({buckshot})

local biobelt = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
biobelt.name = "biological-belt-crate"
biobelt.animation ={
      filename = modname.."/graphics/entity/projectiles/biological-bullet.png",
      frame_count = 1,
      width = 3,
      height = 50,
      priority = "high"
    }
biobelt.action =   {type = "direct", action_delivery = 
	{ type = "instant", target_effects ={
		{type = "damage", damage = {amount = (((NEConfig.BioDamage/NEConfig.Set_Difficulty) + 5) * 5) * 1.2, type = "Biological"}},
		{type = "create-sticker",
          sticker = "tiny-sticker"},
                }}}
data:extend({biobelt})

local shotgunshellcrate = util.table.deepcopy(data.raw.projectile["shotgun-pellet"])
shotgunshellcrate.name = "shotgun-pellet-crate"
shotgunshellcrate.action =    {type = "direct", action_delivery = 
	{ type = "instant", target_effects =
       {type = "damage", damage = {amount = 7.2, type = "physical"}},
      }
    }
data:extend({shotgunshellcrate})

local piercingshotgunshellcrate = util.table.deepcopy(data.raw.projectile["piercing-shotgun-pellet"])
piercingshotgunshellcrate.name = "piercing-shotgun-pellet-crate"
piercingshotgunshellcrate.action =    {type = "direct", action_delivery = 
	{ type = "instant", target_effects =
       {type = "damage", damage = {amount = 7.2, type = "impact"}},
      }
    }
data:extend({piercingshotgunshellcrate})

