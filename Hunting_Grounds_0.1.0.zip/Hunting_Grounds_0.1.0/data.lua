require("util")
require("defines")

require("data_paths")


require("overrides.ammo")
require("overrides.ammo_artillery")
require("overrides.gun")
require("overrides.recipe_military")
require("overrides.projectiles")
require("overrides.technology")
require("overrides.entity")

require("prototypes.ammo")

require("prototypes.ammo-crates")

require("prototypes.gun")

require("prototypes.item")

require("prototypes.categories")

require("prototypes.projectiles")
require("prototypes.projectiles-crates")

require("prototypes.entities")

require("prototypes.recipe.recipes_belt")
require("prototypes.recipe.recipes_bullets")
require("prototypes.recipe.recipes_crates")
require("prototypes.recipe.recipes_shotgun")
require("prototypes.recipe.recipes_items")

require("prototypes.technology.technology_belt")
require("prototypes.technology.technology_belt_upgrades")
require("prototypes.technology.technology_flamethrower_upgrades")
require("prototypes.technology.technology_crates")
require("prototypes.technology.technology_advanced_military")

require("prototypes.Item-Groups.item-groups")

